<div class="mx-auto py-8 max-w-sm text-center text-90">
    <!-- @include('nova::auth.partials.logo') -->
    <img src="/images/nccs_logo.png" alt="NCCS_logo" class="logo-attribute" width="50%" />

</div>
