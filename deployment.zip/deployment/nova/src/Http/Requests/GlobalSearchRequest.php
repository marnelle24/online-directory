<?php

namespace Laravel\Nova\Http\Requests;

class GlobalSearchRequest extends NovaRequest
{
    //
}
